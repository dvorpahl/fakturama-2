<?php
header('Location: ../../');
exit;
